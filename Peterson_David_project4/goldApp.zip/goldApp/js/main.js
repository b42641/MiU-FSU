// main.js
// toBuy Project
// David Peterson 2013/6/19

// FROM VIDEO
var parseAddItem = function(data){
	// USES FORM DATA HERE
};
// END OF FROM VIDEO

$('#home').on('pageinit', function(){
	//code needed for home page goes here
});	
		
$('#addItem').on('pageinit', function(){
		console.log("in addItem");
		var myForm = $('#addItem');
				console.log("in myForm");
		    myForm.validate({
//			invalidHandler: function(form, validator) {},
			submitHandler: function() {

//			storeData(data);
		}
	});
	
	//any other code needed for addItem page goes here
	
});

//The functions below can go inside or outside the pageinit function for the page in which it is needed.

var autofillData = function (){
	 
};

var getData = function(){

};

var storeData = function(data){
	
}; 

var	deleteItem = function (){
			
};
					
var clearLocal = function(){

};

// THIS IS THE END OF THE SAMPLE





/*
$('#home').on('pageinit', function(){
	//code needed for home page goes here
});	
		
$('#addItem').on('pageinit', function(){
	var myForm = $('#formId');
	    myForm.validate({
			invalidHandler: function(form, validator) {
		},
		submitHandler: function() {
		var data = myForm.serializeArray();
		storeData(data);
		}
	});
	
	//any other code needed for addItem page goes here
	
});


//--
$('#addItem').on('pageinit', function(){
	var myForm = $('#addItem');
	console.log("in addItem");

	myForm.validate({
		console.log("in validate");
//		invalidHandler: function(form, validator) {},
		submitHandler: function() {
			console.log("in submitHandler");
			var data = myForm.serializeArray();
			parseAddItem(data);
			console.log(data);
//			storeData(data);
		}
	});
	
	//any other code needed for addItem page goes here
var parseAddItem = function(data){
	// USES FORM DATA HERE
	console.log("in parseAddItem");
	console.log(data);
	};	
});







--//  
*/



//The functions below can go inside or outside the pageinit function for the page in which it is needed.

var autofillData = function (){
	 
};

var getData = function(){

};

var storeData = function(data){
	
}; 

var	deleteItem = function (){
			
};
					
var clearLocal = function(){

};


/*
$('#home').on('pageinit', function(){
	//code needed for home page goes here
});	
	
	



//The functions below can go inside or outside the pageinit function for the page in which it is needed.

var autofillData = function (){
	 
};

var getData = function(){

};

var storeData = function(data){
	
}; 

var	deleteItem = function (){
			
};
					
var clearLocal = function(){

};


$(document).ready(function(){
	var rbform = $('#addItemForm');
	rbform.validate();
});
*/
